import controller as c

c.button_click()